# ArcoLinuxIso Carli-6

Start building your own carli version with 

sudo ./build.sh

To be able to build you install this package

sudo pacman -S archiso

To do : next - change name Arch Linux to Carli